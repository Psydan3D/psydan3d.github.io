<?php
//Code by Sylvain William Martens
include('admin_header.php'); ?>
<h1>Administration</h1>
<script>function numeric(evt){var theEvent=evt||window.event;var key=theEvent.keyCode||theEvent.which;key=String.fromCharCode(key);var regex=/[0-9]|\./;if(!regex.test(key)){theEvent.returnValue=false;if(theEvent.preventDefault)theEvent.preventDefault();}}</script>
<div class="widgets ready" style="display: block;">
    <div class="widget widget-default" style="padding-bottom: 60px;">
        <header class="widget-heading clearfix">
            <span class="widget-icon"><i class="fa fa-lg fa-fw fa-pencil"></i></span>
            <h2> Administration</h2>
        </header>
        <div class="widget-body" style="display: block;">
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingOne">
                  <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                      Header
                    </a>
                  </h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                  <div class="panel-body">
                  <h2>Head Text:</h2><br/>
                   <div class="row">
                      <div class="col-md-6">
                        <form method=post >
                            <label for=slogan>Slogan:</label>
                            <textarea class="form-control" rows="3" name="slogan" id=slogan><?php $slogan = mysql_fetch_assoc($strings_model->GetString("slogan")); echo $slogan['string_value']?></textarea>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                      </div>
                      <div class="col-md-6">
                        <form method=post >
                            <label for=subslogan>Sub Slogan:</label>
                            <textarea class="form-control" rows="3" name="subslogan" id=subslogan><?php $subslogan=mysql_fetch_assoc($strings_model->GetString("subslogan")); echo $subslogan['string_value']?></textarea>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                      </div>
                    </div>
                    <br/>
                    <h2>Social Links:</h2>
                    <div class="row">
                      <div class="col-md-6">
                        <form method=post >
                            <label for=facebook>Facebook:</label>
                            <input type="text" class="form-control" name="facebook" id=facebook value="<?php $facebook=mysql_fetch_assoc($strings_model->GetString("facebook")); echo $facebook['string_value']?>"/>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                        <form method=post >
                            <label for=twitter>Twitter:</label>
                            <input type="text" class="form-control" name="twitter" id=twitter value="<?php $twitter=mysql_fetch_assoc($strings_model->GetString("twitter")); echo $twitter['string_value'];?>"/>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                        <form method=post >
                            <label for=linkedin>Linked in:</label>
                            <input type="text" class="form-control" name="linkedin" id=linkedin value="<?php $linkedin = mysql_fetch_assoc($strings_model->GetString("linkedin")); echo $linkedin['string_value'];?>"/>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                      </div>
                      <div class="col-md-6">
                        <form method=post >
                            <label for=google>Google+:</label>
                            <input type="text" class="form-control" name="google" id=google value="<?php $google=mysql_fetch_assoc($strings_model->GetString("google")); echo $google['string_value'];?>"/>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                        <form method=post >
                            <label for=devianart>Devian Art:</label>
                            <input type="text" class="form-control" name="devianart" id=devianart value="<?php $devianart=mysql_fetch_assoc($strings_model->GetString("devianart")); echo $devianart['string_value'];?>"/>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                        <form method=post >
                            <label for=dribble>Twitch:</label>
                            <input type="text" class="form-control" name="dribble" id=dribble value="<?php $dribble =mysql_fetch_assoc($strings_model->GetString("dribble")); echo $dribble['string_value'];?>"/>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingTwo">
                  <h4 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                      About Page
                    </a>
                  </h4>
                </div>
                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                  <div class="panel-body">
                    <div class="row">
                      <div class="col-md-6">
                        <h1>MY PICTURE:</h1>
                        <form method=post enctype="multipart/form-data">
                            <img src="../static/images/about.png" width=300 /><br/>
                            <label for=fileToUpload>Select image to upload:</label>
                            <input type="file" name="myPicture" id="fileToUpload">
                            <input type=submit class=btn value="Save"/>
                        </form>                      
                      </div>
                      <div class="col-md-6">
                        <h1>ABOUT ME:</h1>
                        <form method=post >
                            <label for=description>Description:</label>
                            <textarea class="form-control" rows="3" name="description" id=description><?php $description=mysql_fetch_assoc($strings_model->GetString("about_me")); echo $description['string_value'];?></textarea>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                      </div>
                    </div>
                    <form method=post enctype="multipart/form-data">
                        <label for=fileToUpload>Select a resume to upload:</label>
                        <input type="file" name="myResume" id="fileToUpload">
                        <input type=submit class=btn value="Save"/>
                    </form>
                    <h1>MY SKILLS:</h1>
                    <form method=post >
                        <label for=skills>Skills Text:</label>
                        <textarea class="form-control" rows="3" name="skills" id=skills><?php $skills =mysql_fetch_assoc($strings_model->GetString("skills")); echo $skills['string_value'];?></textarea>
                        <br>
                        <input type=submit class=btn value="Save"/>
                    </form>
                    <form method=post >
                        <table style="width:100%">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Percent</th>
                                    <th></th>
                                </tr>    
                            </thead>
                            <tbody>
                                <tr>
                                    <th style="padding-right:50px;"><input class="form-control" type=text name=skillName /></th>
                                    <th><input class="form-control" type=text name=percent maxlength=3 onkeypress='numeric(event)' onblur="if(this.value>100)this.value=100;"/></th>
                                    <th style="text-align:center;"><input class=btn type=submit value=Add /></th>
                                </tr>    
                            </tbody>
                        </table>
                    </form>
                        <br/>
                        <table style="width:100%">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Percent</th>
                                    <th>Options</th>
                                </tr>    
                            </thead>
                            <tbody>
                                <?php
                                $skills = $skills_model->GetSkills();
                                while($skill = mysql_fetch_assoc($skills))
                                {?><tr id="skill_<?=$skill['id'];?>" style="border-bottom:1px solid black;">
                                    <th style="padding-right:50px;width: 50%;"><input id="name" class="form-control" type=text name=name value="<?=$skill['name'];?>"/></th>
                                    <th style="width: 40%;"><input id="percent" class="form-control" type=text name=percent maxlength=3 onkeypress='numeric(event)' onblur="if(this.value>100)this.value=100;" value="<?=$skill['percent'];?>"/></th>
                                    <th style="text-align:center;"><input class=btn type=button value=Save onclick="SetSkill(<?=$skill['id'];?>);"/> <input class=btn type=button value=Remove onclick="RemoveSkill(<?=$skill['id'];?>);"/></th>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        <script>
                        function RemoveSkill(skillId)
                        {
                            bootbox.confirm("Are you sure?", function(result) {
                                if(result==true)
                                {
                                    jQuery.ajax({
                                        type: "POST",
                                        url: "<?php echo BASE_URL; ?>ajax/removeSkill/"+skillId,
                                        success: function( data ) {
                                            if(data=="success")
                                            {
                                                $("skill_"+skillId).remove();
                                            }//Else we can maybe show a prompt explaining something went wrong...
                                        },
                                    });
                                }
                            }); 
                        }
                        function SetSkill(skillId)
                        {
                            bootbox.confirm("Are you sure?", function(result) {
                                if(result==true)
                                {
                                    var name = jQuery("#skill_"+skillId+" #name").val();
                                    var percent = jQuery("#skill_"+skillId+" #percent").val();
                                    jQuery.ajax({
                                        type: "POST",
                                        url: "<?php echo BASE_URL; ?>ajax/setSkill/"+skillId,
                                        data:"skillName="+name+"&percent="+percent,
                                        success: function( data ) {
                                            if(data=="success")
                                            {
                                                //Show a little success prompt...
                                            }//Else we can maybe show a prompt explaining something went wrong...
                                        },
                                    });
                                }
                            }); 
                        }
                        </script>
                        <br/>
                        <br/>                
                    </form>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingThree">
                  <h4 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                      Testimonials
                    </a>
                  </h4>
                </div>
                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                  <div class="panel-body">
                    <!--TODO: i work Here-->
                    <form method=post enctype="multipart/form-data">
                    <table style="width:100%;">
                        <thead>
                            <tr>
                                <th width="30%">Client Name</th>
                                <th width="30%">Client Text</th>
                                <th width="30%">Client Logo</th>
                                <th width="10%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th><input class="form-control" style="width:50%;" type="text" name=client_name /></th>
                                <th><input class="form-control" style="width:50%;" type="text" name=client_text /></th>
                                <th><input class="fileInput" type="file" name="client_picture"/></th>
                                <th><input type="submit" value=Add class=btn /></th>
                            </tr>
                        </tbody>
                    </table>
                    </form>
                    <br/>
                    <br/>
                    <table style="width:100%;">
                        <thead>
                            <tr>
                                <th width="30%">Client Name</th>
                                <th width="30%">Client Text</th>
                                <th width="30%">Client Logo</th>
                                <th width="10%">Options</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $testimonials = $testimonials_model->GetTestimonials();
                            while($testimonial = mysql_fetch_assoc($testimonials)){ ?>
                            <tr id="testimonial_<?=$testimonial['id'];?>">
                                <th><input class="form-control" style="width:50%;" type="text" name=client_name value="<?=$testimonial['client_name'];?>" id=client_name_<?=$testimonial['id'];?> /></th>
                                <th><input class="form-control" style="width:50%;" type="text" name=client_text value="<?=$testimonial['description'];?>" id=description_<?=$testimonial['id'];?> /></th>
                                <th><img id="logo_<?=$testimonial['id'];?>" src="../<?=$testimonial['picture'];?>" height=74 width=74 /> <input id=picture_<?=$testimonial['id'];?> class="fileInput" type="file" name="client_picture"/></th>
                                <th><input type="button" value=Edit class=btn onclick="SetTestimonial(<?=$testimonial['id'];?>);"/> <input type="button" value=Remove class=btn onclick="RemoveTestimonial(<?=$testimonial['id'];?>);" /></th>
                            </tr><?php } ?>
                        </tbody>
                    </table>
                    <script>
                        function RemoveTestimonial(skillId)
                        {
                            bootbox.confirm("Are you sure?", function(result) {
                                if(result==true)
                                {
                                    jQuery.ajax({
                                        type: "POST",
                                        url: "<?php echo BASE_URL; ?>ajax/removeTestimonial/"+skillId,
                                        success: function( data ) {
                                            if(data=="success")
                                            {
                                                $("testimonial_"+skillId).remove();
                                            }//Else we can maybe show a prompt explaining something went wrong...
                                        },
                                    });
                                }
                            }); 
                        }
                        
                        function SetTestimonial(skillId)
                        {
                            bootbox.confirm("Are you sure?", function(result) {
                                if(result==true)
                                {
                                    var client_name = jQuery("#client_name_"+skillId).val();
                                    var description = jQuery("#description_"+skillId).val();
                                    //var picture = jQuery("#picture_"+skillId).val();
                                    var picture = document.getElementById("picture_"+skillId).files[0];
                                    var request = new FormData();
                                    
                                    request.append('client_name', client_name);
                                    request.append('client_text', description);
                                    request.append('client_picture', picture);
                                    jQuery.ajax({
                                        type: "POST",
                                        contentType: 'multipart/form-data',
                                        processData: false,
                                        contentType: false,
                                        url: "<?php echo BASE_URL; ?>ajax/setTestimonial/"+skillId,
                                        data: request,
                                        success: function( data ) {
                                            if(data=="success")
                                            {
                                                document.getElementById("logo_"+skillId).src= "";//This Should Refresh the cache...
                                                document.getElementById("logo_"+skillId).src= "../static/images/testimonials/"+client_name+".png";
                                                //Show a little success prompt...
                                            }//Else we can maybe show a prompt explaining something went wrong...
                                        },
                                    });
                                }
                            }); 
                        }
                    </script>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingFour">
                  <h4 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                      Contact
                    </a>
                  </h4>
                </div>
                <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                  <div class="panel-body">
                    <h1>Text:</h1>
                    <div class="row">
                      <div class="col-md-6">  
                        <form method=post >
                            <label for=contact_h1>Header 1:</label>
                            <textarea class="form-control" rows="3" name="contact_h1" id=contact_h1><?php $contact_h1=mysql_fetch_assoc($strings_model->GetString("contact_h1")); echo $contact_h1['string_value'];?></textarea>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>          
                      </div>
                      <div class="col-md-6">
                        <form method=post >
                            <label for=contact_h2>Header 2:</label>
                            <textarea class="form-control" rows="3" name="contact_h2" id=contact_h2><?php $contact_h2=mysql_fetch_assoc($strings_model->GetString("contact_h2")); echo $contact_h2['string_value'];?></textarea>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">  
                        <form method=post >
                            <label for=contact_subtext>Sub Text:</label>
                            <textarea class="form-control" rows="3" name="contact_subtext" id=contact_subtext><?php $contact_subtext=mysql_fetch_assoc($strings_model->GetString("contact_subtext")); echo $contact_subtext['string_value'];?></textarea>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                        <form method=post >
                            <label for=contact_email>Email: (Message will be forwarded to this email)</label>
                            <input type="text" class="form-control" name="contact_email" id=contact_email value="<?php $contact_email=mysql_fetch_assoc($strings_model->GetString("contact_email")); echo $contact_email['string_value'];?>"/>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                      </div>
                      <div class="col-md-6">
                        <form method=post >
                            <label for=contact_address>Address:</label>
                            <input type="text" class="form-control" name="contact_address" id=contact_address value="<?php $contact_address=mysql_fetch_assoc($strings_model->GetString("contact_address")); echo $contact_address['string_value'];?>"/>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                        <form method=post >
                            <label for=contact_phone>Phone:</label>
                            <input type="text" class="form-control" name="contact_phone" id=contact_phone value="<?php $contact_phone=mysql_fetch_assoc($strings_model->GetString("contact_phone")); echo $contact_phone['string_value'];?>"/>
                            <br>
                            <input type=submit class=btn value="Save"/>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
</div>
<?php include('admin_footer.php'); ?>