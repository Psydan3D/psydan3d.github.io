<?php
//Code by Sylvain William Martens
include('admin_header.php'); ?>
<h1>Portfolio - Add an Item</h1>
<div class="widgets ready" style="display: block;">
    <div class="widget widget-default" style="padding-bottom: 60px;">
        <header class="widget-heading clearfix">
            <span class="widget-icon"><i class="fa fa-lg fa-fw fa-pencil"></i></span>
            <h2> Add a Portfolio Item</h2>
        </header>
        <div class="widget-body" style="display: block;">
			<div id="errors"></div>
            <h3>Project Details:</h3>
            <br/>
            <form id="myForm" method=post >
                <input type=hidden name=doPost value=true />
                <label for=name >Project Name:</label>
                <input type=text class="form-control" name=name id=name value="<?=$project_name;?>" />
                <br/>
                <div class=row>
                    <div class="col-md-6">
                        <label for=description >Project Description:</label>
                        <textarea class="form-control" name=description id=description rows=13><?=$project_description;?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label for=category >Project Category:</label>
                        <select class="form-control" name=category id=category>
                            <?php $categories = $portfolio_model->GetCategories(); while($category = mysql_fetch_assoc($categories)){ ?>
                            <option <?php if($project_selected_catId == $category['id']) echo 'selected'; ?> value="<?=$category['id'];?>"><?=$category['name'];?></option>
                            <?php } ?>
                            <!--TODO: GRAB CATEGORY LIST AND ECHO IT HERE...-->
                        </select>
                        <br/>
                        <label for=dateAt >Project Date:</label>
                        <input type=text class="form-control" name=dateAt id=dateAt value="<?=$project_date;?>" />
                        <br/>
                        <label for=client >Client Name:</label>
                        <input type=text class="form-control" name=client id=client value="<?=$project_client;?>" />
                        <br/>
                        <label for=link >Project Link:</label>
                        <input type=text class="form-control" name=link id=link value="<?=$project_link;?>" />                        
                    </div>
                </div>
            <br>
            <h3>Attachments:</h3>
            <br/>
			<style>
				#selectedFiles img {
					max-width: 200px;
					max-height: 200px;
					float: left;
					margin-bottom:10px;
				}
			</style>
			Files: <input type="file" id="files" name="files" multiple><br/>
			<table width="100%">
					<thead>
						<tr>
							<th>Attachment</th>
							<th>Name</th>
							<th>Option</th>
						</tr>
					</thead>
					<tbody id="selectedFiles"></tbody>
				</table>
		<script>
			var selDiv = "";
			var storedFiles = [];
			jQuery(document).ready(function() {
				jQuery("#files").on("change", handleFileSelect);		
				selDiv = jQuery("#selectedFiles"); 
				jQuery("#myForm").on("submit", handleForm);		
				jQuery("body").on("click", "#selFile", removeFile);
			});		
			function handleFileSelect(e) {
				var files = e.target.files;
				var filesArr = Array.prototype.slice.call(files);
				filesArr.forEach(function(f) {
					if(!f.type.match("image.*")) {
						return;
					}
					storedFiles.push(f);					
					var reader = new FileReader();
					reader.onload = function (e) {
						var html = "<tr><th><img src=\"" + e.target.result + "\"></th><th>" + f.name + "</th><th><input id='selFile' class='form-control' type=button value=Remove data-file='"+f.name+"' /></th></tr>";
						selDiv.append(html);				
					}
					reader.readAsDataURL(f); 
				});		
			}		
			function handleForm(e) {
				e.preventDefault();
				var data = new FormData();		
				for(var i=0, len=storedFiles.length; i<len; i++) {
					data.append('files[]', storedFiles[i]);
				}
				data.append('doPost', "true");
				data.append('name', document.getElementById("name").value);
				data.append('description', document.getElementById("description").value);
				data.append('category', document.getElementById("category").value);
				data.append('dateAt', document.getElementById("dateAt").value);
				data.append('client', document.getElementById("client").value);
				data.append('link', document.getElementById("link").value);
				var xhr = new XMLHttpRequest();
				xhr.open('POST', 'addItem', true);
				xhr.onload = function(e) {
					if(this.status == 200) {
						if(e.currentTarget.responseText == "success")
						{
							location.href = "http://www.psydan3d.co.uk/admin/portfolio";
						}else{
							jQuery("#errors").html('<div class="alert alert-danger" role="alert">'+e.currentTarget.responseText+'</div>');
						}					
					}else{
						alert("An error occured.");
					}
				}
				xhr.send(data);
			}		
			function removeFile(e) {
				var file = jQuery(this).data("file");
				for(var i=0;i<storedFiles.length;i++) {
					if(storedFiles[i].name === file) {
						storedFiles.splice(i,1);
						break;
					}
				}
				jQuery(this).parent().parent().remove();
			}
			</script>
            <br>
            <input type=submit value="Create" class="form-control"/>
            <br/>
            </form>
        </div>
    </div>
</div>
<?php include('admin_footer.php'); ?>