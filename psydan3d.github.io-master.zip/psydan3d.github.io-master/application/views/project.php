<?php
//Code by Sylvain William Martens
include('header.php'); ?>
<h3 class="page-title" style="margin-top:50px;"><?=$title?></h3>
<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 blogleft">
       	  
        <article class="project clearfix">
        <?php
        $attachments = $portfolio_model->GetAttachments($project['id']);
        while($attachment = mysql_fetch_assoc($attachments)){
		if (0 === strpos($attachment['attachment_path'], 'data')) {
		?>
			<div class="projectImage">
                <img src="<?=$attachment['attachment_path'];?>" class="img-responsive postImage" alt="">
            </div>
		<?php }else{ ?>
			<div class="projectImage">
                <img src="../../<?=$attachment['attachment_path'];?>" class="img-responsive postImage" alt="">
            </div>
		<?php }
        } ?>
        </article>
        <div class="postnav clearfix">
        <?php
        $prevPost = $portfolio_model->GetPreviousPostLinkName($project['id']);
        if($prevPost!=null){
        ?>
        <a href="<?=$prevPost;?>" class="post-prev">Older Post</a>
        <?php
        }
        $nextPost = $portfolio_model->GetNextPostLinkName($project['id']);
        if($nextPost!=null){
        ?>
        <a href="<?=$nextPost;?>" class="post-next">Previous Post</a>
        <?php } ?>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-md-offset-1 col-lg-offset-1 col-sm-offset-1 col-xs-offset-0 blogsidebar">
        <aside class="widget">
            <h3 class="sidebarprojecttitle">Project Category</h3>
            <p class="sidebarEntry"><?=$portfolio_model->GetCategoryName($project['category_id'])?></p>
            <?php
            $dateAt = $project['dateAt'];
            if($dateAt != null && $dateAt != ""){
            ?>
            <h3 class="sidebarprojecttitle">Date</h3>
            <p class="sidebarEntry"><?=$dateAt;?></p>
            <?php
            }
            $clientName = $project['client_name'];
            if($clientName != null && $clientName != ""){ ?>
            <h3 class="sidebarprojecttitle">Client name</h3>
            <p class="sidebarEntry"><?=$clientName?></p>
            <?php
            }
            $description = $project['description'];
            if($description != null && $description != ""){ ?>
            <h3 class="sidebarprojecttitle">Project Details</h3>
            <p class="sidebarEntry"><?=$description;?></p>
            <?php
            }
            $link = $project['project_link'];
            if($link != null && $link != ""){ ?>
            <h3 class="sidebarprojecttitle">Project Link</h3>
            <p class="sidebarEntry"><a href="<?=$link;?>"><?=$link;?></a></p><?php } ?>
        </aside>
    </div>
</div>
<?php include('footer.php'); ?>