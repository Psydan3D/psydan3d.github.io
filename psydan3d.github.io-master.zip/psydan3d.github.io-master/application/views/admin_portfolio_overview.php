<?php
//Code by Sylvain William Martens
include('admin_header.php'); ?>
<h1>Portfolio - Overview</h1>
<div class="widgets ready" style="display: block;">
    <div class="widget widget-default" style="padding-bottom: 60px;">
        <header class="widget-heading clearfix">
            <span class="widget-icon"><i class="fa fa-lg fa-fw fa-pencil"></i></span>
            <h2> Categories</h2>
        </header>
        <div class="widget-body" style="display: block;">
            <h3>Add a category</h3>
            <br>
            <form method=post >
            <table width="100%">
                <thread>
                    <tr>
                        <th>Category Name</th>
                        <th>Category Description</th>
                        <th></th>
                    </tr>
                </thread>
                <tbody>
                    <tr>
                        <th><input type=text name=category_name class="form-control"/></th>
                        <th><input type=text name=category_description class="form-control"/></th>
                        <th><input type=submit class="form-control" value=Add /></th>
                    </tr>
                </tbody>
            </table>
            </form>
            <br>
            <h3>Manage categories</h3>
            <br>
            <table width="100%">
                <thread>
                    <tr>
                        <th>Category Name</th>
                        <th>Category Description</th>
                        <th>Options</th>
                    </tr>
                </thread>
                <tbody>
                    
                    <?php $categories = $portfolio_model->GetCategories(); while($category = mysql_fetch_assoc($categories)){ ?>
                    <tr id="category_<?=$category['id'];?>">
                        <th><input type=text id=category_name name=category_name class="form-control" value="<?=$category['name'];?>"/></th>
                        <th><input type=text id=category_description name=category_description class="form-control" value="<?=$category['description'];?>"/></th>
                        <th><input type=button class="form-control" value=Edit style="width:50%;float:left;" onclick="SetCategory(<?=$category['id'];?>);" /> <input type=button class="form-control" value=Remove style="width:50%;float:left;" onclick="RemoveCategory(<?=$category['id'];?>);" /></th>
                    </tr><?php } ?>
                </tbody>
            </table><br/>
            <script>
                function RemoveCategory(catId)
                {
                    bootbox.confirm("Are you sure?", function(result) {
                        if(result==true)
                        {
                            jQuery.ajax({
                                type: "POST",
                                url: "<?php echo BASE_URL; ?>ajax/removeCategory/"+catId,
                                success: function( data ) {
                                    if(data=="success")
                                    {
                                        $("category_"+catId).remove();
                                    }//Else we can maybe show a prompt explaining something went wrong...
                                },
                            });
                        }
                    }); 
                }
                function SetCategory(catId)
                {
                    bootbox.confirm("Are you sure?", function(result) {
                        if(result==true)
                        {
                            var category_name = jQuery("#category_"+catId+" #category_name").val();
                            var category_description = jQuery("#category_"+catId+" #category_description").val();
                            jQuery.ajax({
                                type: "POST",
                                url: "<?php echo BASE_URL; ?>ajax/setCategory/"+catId,
                                data:"category_name="+category_name+"&category_description="+category_description,
                                success: function( data ) {
                                    if(data=="success")
                                    {
                                        //Show a little success prompt...
                                    }//Else we can maybe show a prompt explaining something went wrong...
                                },
                            });
                        }
                    }); 
                }
            </script>
        </div>
    </div>
</div>
<div class="widgets ready" style="display: block;">
    <div class="widget widget-default" style="padding-bottom: 60px;">
        <header class="widget-heading clearfix">
            <span class="widget-icon"><i class="fa fa-lg fa-fw fa-pencil"></i></span>
            <h2> Items</h2>
        </header>
        <div class="widget-body" style="display: block;">
            <table width="100%">
                <thead>
                    <tr>
                        <th>Project Thumbnail</th>
                        <th>Project Name</th>
                        <th>Project Description</th>
                        <th>Options</th>
                    </tr>
                </thead>
                <tbody>
                <?php $items = $portfolio_model->GetItems(); while($item = mysql_fetch_assoc($items)){ ?>
                    <tr id="item_<?=$item['id'];?>">
                        <th>
                        <?php
                        $picture = mysql_fetch_assoc($portfolio_model->GetAttachments($item['id'])); $picture = $picture['attachment_path'];
                        if($picture != null && $picture != ""){
						if (0 === strpos($picture, 'data')) {
                        ?>
                        <img src="<?=$picture?>" width=100 /></th>
                        <?php }else{ ?>
						<img src="../<?=$picture?>" width=100 /></th>
						<?php }
						} ?>
                        <th><?=$item['name'];?></th>
                        <th><?=$item['description'];?></th>
                        <th><input type=button class="form-control" value=Edit style="width:50%;float:left;" onclick="location.href = 'editItem/<?=$item['id'];?>';" /> <input type=button class="form-control" value=Remove style="width:50%;float:left;" onclick="RemoveItem(<?=$item['id'];?>);" /></th>
                    </tr>
                <?php } ?>
                </tbody>
            </table><br/>
            <script>
                function RemoveItem(itemId)
                {
                    bootbox.confirm("Are you sure?", function(result) {
                        if(result==true)
                        {
                            jQuery.ajax({
                                type: "POST",
                                url: "<?php echo BASE_URL; ?>ajax/removeItem/"+itemId,
                                success: function( data ) {
                                    if(data=="success")
                                    {
                                        $("item_"+itemId).remove();
                                    }//Else we can maybe show a prompt explaining something went wrong...
                                },
                            });
                        }
                    }); 
                }
            </script>
        </div>
    </div>
</div>
<?php include('admin_footer.php'); ?>