<?php
//Code by Sylvain William Martens?></div></div>
<footer id="ribbon">&copy; 2015 Psydan3D. All rights Reserverd</footer>
<!-- #JAVASCRIPT -->
<script>if (!window.jQuery) {document.write('<script src="<?php echo BASE_URL; ?>static/admin/js/jquery.min.js"><\/script>');}</script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script>if (!window.jQuery.ui) {document.write('<script src="<?php echo BASE_URL; ?>static/admin/js/jquery-ui-1.10.3.min.js"><\/script>');}</script>
<script src="<?php echo BASE_URL; ?>static/admin/js/jquery.ui.touch-punch.min.js"></script>
<script src="<?php echo BASE_URL; ?>static/admin/js/bootstrap.min.js"></script>
<!--[if IE 8]><h1>Your browser is out of date, please update your browser by going to www.microsoft.com/download</h1><![endif]-->
<script src="<?php echo BASE_URL; ?>static/admin/js/prototype.js"></script>
<script src="<?php echo BASE_URL; ?>static/admin/js/app.min.js"></script>
<script src="<?php echo BASE_URL; ?>static/admin/js/bootbox.min.js"></script>
</body>
</html>