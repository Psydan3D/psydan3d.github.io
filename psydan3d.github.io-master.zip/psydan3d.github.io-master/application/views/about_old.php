<?php
//Code by Sylvain William Martens
include('header.php'); ?>
<div class="row content" style="margin-top:50px;"> 
    <!--About image start -->
    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 cl"> <img src="static/images/about.png" class="img-responsive" alt=""> </div>
    <!--About image start -->
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 cr"> 
      <!--About content start -->
      <div class="cb clearfix">
        <h3>About me</h3>
        <p><?php $about_me = mysql_fetch_assoc($strings_model->GetString("about_me")); echo nl2br($about_me['string_value']);?></p>
        <a href="<?php $path_resume = mysql_fetch_assoc($strings_model->GetString("path_resume")); echo $path_resume['string_value'];?>" class="dl">Download resume</a> </div>
      <!--About content start --> 
      <!--Skill area start-->
      <div class="cb clearfix">
        <h3>My Skills</h3>
        <p><?php $skills = mysql_fetch_assoc($strings_model->GetString("skills")); echo nl2br($skills['string_value']);?></p>
        <div class="sM">
        <?php
        $skills = $skills_model->GetSkills();
        while($skill = mysql_fetch_assoc($skills))
        {
            ?>
            <div class="sMB"> <span class="sn"><?=$skill['name'];?></span>
            <div class="row">
                <div class="progressBg col-lg-11 col-md-11 col-sm-11 col-xs-12">
                <div class="pdata" style="width:<?=$skill['percent'];?>%;"></div>
                </div>
                <span class="pvalue col-lg-1 col-md-1 col-sm-1 col-xs-12"><?=$skill['percent'];?>%</span> </div>
            </div>            
            <?php
        }
        ?>
        </div>
      </div>
    </div>
</div>
<?php include('footer.php'); ?>