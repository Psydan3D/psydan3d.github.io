<?php
//Code by Sylvain William Martens
$tesimonials = $testimonials_model->GetTestimonials();
?></div>
<div class="footerTop container">
  <div class="fc">
    <div class="imageSlide">
    <?php while($testimonial = mysql_fetch_assoc($tesimonials)){ ?>
      <div class="imageBox"><img src="<?php echo BASE_URL.$testimonial['picture'];?>" width="74" height="74"></div>
    <?php } if(mysql_num_rows($tesimonials) > 0) mysql_data_seek($tesimonials, 0);
    ?>
    </div>
  </div>
  <div class="footerTopContent">
    <ul class="slides testimonialText list-unstyled">
    <?php while($testimonial = mysql_fetch_assoc($tesimonials)){ ?>
      <li>
        <h3 class="font-openBold">"<?=$testimonial['description'];?>"</h3>
        <h4><?=$testimonial['client_name'];?></h4>
      </li><?php } ?>
    </ul>
  </div>
</div>
<!--Testimonial end--> 
<!--footer start-->
<footer class="footer">
  <div class="container">
    <ul class="list-unstyled footerLink">
        <li><a href="<?php echo BASE_URL; ?>">work</a></li>
        <li><a href="<?php echo BASE_URL; ?>about" href="#">about</a></li>
        <li><a href="<?php echo BASE_URL; ?>contact">contact</a></li>
    </ul>
    <p class="copyrightText">&copy; Psydan 2015. All Rights reserved</p>
  </div>
</footer>
<!--footer end-->
<!--Javascriptfile start -->
<script type="text/javascript" src="<?php echo BASE_URL; ?>static/js/jquery.min.js"></script> 
<script type="text/javascript" src="<?php echo BASE_URL; ?>static/js/bootstrap.js"></script> 
<script src="<?php echo BASE_URL; ?>static/js/masonry.pkgd.min.js"></script> 
<script src="<?php echo BASE_URL; ?>static/js/imagesloaded.pkgd.min.js"></script> 
<script src="<?php echo BASE_URL; ?>static/js/classie.js"></script> 
<script src="<?php echo BASE_URL; ?>static/js/colorfinder-1.1.js"></script> 
<script src="<?php echo BASE_URL; ?>static/js/gridScrollFx.js"></script> 
<?php
if($title == "Freelance 3D modeling and design services"){?>
<script>
var offset = 1;//Start from 1 since 0 is already displayed
$(".vc").not(".disabled").click(function(e) {
	        e.preventDefault();//This should prevent from returning to the top of the page...
            $(this).blur();
            $.ajax({
                type: "POST",
                url: "ajax/loadMorePortfolioItems/"+offset,
                success: function( data ) {
                    offset++;
                    if(data == "END")
                    {
                        //Change btn text and disable it ( prevent spam )
                        $("#loadMoreBtn").addClass("disabled").text("The End");
                    }else{
                        $("ul#grid").append(data);
                        $(".pf-slider").each(function(index, element) {
			                $(this).height($(this).parents("li").height()-116);
                            $(this).find("img").css({"left":"100%"});
			                $(this).find("img:first").css({"left":0}).addClass("currentSlide");
			                $(this).find(".prevLink").hide();
                        });
	                    new GridScrollFx( document.getElementById( 'grid' ), {
		                    minDelay : 0,
							maxDelay : 100,
							viewportFactor : 0
	                    } );
                    }
                },
            });
        });
var masonryClass, container = $("#grid");
GridScrollFx.prototype.options = {
	minDelay : 0,
	maxDelay : 100,
	viewportFactor : 0
}
new GridScrollFx( document.getElementById( 'grid' ), {
	minDelay : 0,
	maxDelay : 100,
	viewportFactor : 0
} );
	
	$(function(){
		$(".hiddenElm li").each(function(index, element) {
			//console.log("attr added");
			$(this).attr({"di":index});
			})
		$(".pf-slider").each(function(index, element) {
			$(this).height($(this).parents("li").height()-116);
            $(this).find("img").css({"left":"100%"});
			$(this).find("img:first").css({"left":0}).addClass("currentSlide");
			$(this).find(".prevLink").hide();
        });
		$("body").on("click",".slideLink",function(e){
			//var getClass =	
			e.preventDefault();
			var $this=$(this);
			var getpar = $(this).parents(".pf-slider");
			if($(this).hasClass("nextLink")){
				//alert(getpar.find("img").length);
				$(this).siblings(".prevLink").show();
				var getcur = getpar.find(".currentSlide");
				var nexElm = getcur.next("img");
				
				nexElm.css({
					"left":"100%",
					"z-index":10
				});
				nexElm.animate({
					"left":0
					},"slow",
				function(){
					getcur.css({"left":"100%"}).removeClass("currentSlide");
					nexElm.addClass("currentSlide");	
					if(nexElm.next("img").length==0){
						$this.hide();
					}
				})
				
			}
			else{
				$(this).siblings(".nextLink").show();
				var getcur = getpar.find(".currentSlide");
				var preElm = getcur.prev("img");
								
				preElm.css({
					"left":(-1*getpar.width()),
					"z-index":10
				});
				preElm.animate({
					"left":0
					},"slow",
				function(){
					getcur.css({"left":"100%"}).removeClass("currentSlide");
					preElm.addClass("currentSlide");	
					if(preElm.prev("img").length==0){
						$this.hide();
					}
				})
				}
		})
	});	
</script><?php } ?>
<script>
var activeImage;
$(document).ready(function(e) {
	var getmaxHeight = 0;
	$(".testimonialText li").each(function(index, element) {
        if($(this).height()>getmaxHeight){
			getmaxHeight = $(this).height();
			$(".footerTopContent").height(getmaxHeight);
			}
    });
	
    $(".testimonialText li").fadeTo("fast",0);
	$(".testimonialText li:first").fadeTo("fast",1);
	$(".imageSlide .imageBox").removeClass("activeImage");
	$(".imageSlide .imageBox:first").addClass("activeImage");
	$(".imageSlide .imageBox").mouseenter(function(){
		if(!$(this).hasClass("activeImage")){
			var gi = $(this).index();
			//console.log(gi);
			$(".imageSlide .imageBox").removeClass("activeImage");
			$(this).addClass("activeImage");
			$(".testimonialText li").fadeTo("fast",0);
			$(".testimonialText li:eq("+gi+")").fadeTo("fast",1);
			}
	})
});
</script>
</body>
</html>