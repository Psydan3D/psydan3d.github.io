<?php
//Code by Sylvain William Martens
include('admin_header.php'); ?>
<h1>Analysis</h1>
<?php include('admin_footer.php'); ?>