<?php
//Code by Sylvain William Martens
include('admin_header.php'); ?>
<h1>Portfolio - Add an Item</h1>
<div class="widgets ready" style="display: block;">
    <div class="widget widget-default" style="padding-bottom: 60px;">
        <header class="widget-heading clearfix">
            <span class="widget-icon"><i class="fa fa-lg fa-fw fa-pencil"></i></span>
            <h2> Add a Portfolio Item</h2>
        </header>
        <div class="widget-body" style="display: block;">
            <?php if($error != "")
            {
            ?>
            <div class="alert alert-danger" role="alert"><?=$error;?></div>
            <?php
            }else if($success){ ?>
            <div class="alert alert-success" role="alert"><?=$success_msg;?></div>
            <?php } ?>
            <h3>Project Details:</h3>
            <br/>
            <form method=post enctype="multipart/form-data">
                <input type=hidden name=doPost value=true />
                <label for=name >Project Name:</label>
                <input type=text class="form-control" name=name id=name value="<?=$project_name;?>" />
                <br/>
                <div class=row>
                    <div class="col-md-6">
                        <label for=description >Project Description:</label>
                        <textarea class="form-control" name=description id=description rows=13><?=$project_description;?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label for=category >Project Category:</label>
                        <select class="form-control" name=category id=category>
                            <?php $categories = $portfolio_model->GetCategories(); while($category = mysql_fetch_assoc($categories)){ ?>
                            <option <?php if($project_selected_catId == $category['id']) echo 'selected'; ?> value="<?=$category['id'];?>"><?=$category['name'];?></option>
                            <?php } ?>
                            <!--TODO: GRAB CATEGORY LIST AND ECHO IT HERE...-->
                        </select>
                        <br/>
                        <label for=dateAt >Project Date:</label>
                        <input type=text class="form-control" name=dateAt id=dateAt value="<?=$project_date;?>" />
                        <br/>
                        <label for=client >Client Name:</label>
                        <input type=text class="form-control" name=client id=client value="<?=$project_client;?>" />
                        <br/>
                        <label for=link >Project Link:</label>
                        <input type=text class="form-control" name=link id=link value="<?=$project_link;?>" />                        
                    </div>
                </div>
            <br>
            <input type=submit value="Modify" class="form-control"/>
            <br/>
            </form>
        </div>
    </div>
</div>
<?php include('admin_footer.php'); ?>