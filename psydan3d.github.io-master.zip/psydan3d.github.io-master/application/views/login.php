<?php
//Code by Sylvain William Martens?><!DOCTYPE html>
<html lang="en-us" class=" -webkit-">
<head>
  <meta charset="utf-8">
  <title><?php echo $title;?></title>
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" type="text/css" media="screen" href="<?php echo BASE_URL; ?>static/admin/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" media="screen" href="<?php echo BASE_URL; ?>static/admin/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" media="screen" href="<?php echo BASE_URL; ?>static/admin/css/main.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,300,400,700">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
</head>
<body>
<header id="header">
	<div id="logo-group"><span id="logo"><h1 style="margin-top:-01px;width:190px;height:20px;">Admin Panel</h1></span></div>
</header>
<div style="position:absolute;width:300px;margin-left:-150px;left:50%;background-color:#F5F2F2;border:1px solid #CCC;border-radius:3px;padding:50px;margin-top:50px;">
    <h1 style="text-align:center;margin-top:-25px;">Login</h1>
    <b style="color:red;"><?php echo $error_message; ?></b>
    <form method="post">
        <input type="hidden" name="login" value="true"/>
        Email Address:<br/>
        <input style="width:100%;" type="email" name="email_address" value="<?php echo $email_address;?>" required="required"/><br/>
        Password:<br />
        <input style="width:100%;" type="password" name="password" required="required"/><br/><br/>
        <input style="width:100%;" class="btn btn-default" type="submit" value="Login"/>
    </form>
</div>
</body>
</html>