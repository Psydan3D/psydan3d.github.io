<?php
//Code by Sylvain William Martens
include('header.php'); ?>
<style>
.img-responsive {
	cursor:pointer;
}
</style>
<ul class="list-unstyled portfolioList grid swipe-rotate" id="grid">
<?php
$items = $portfolio_model->GetLatest10Items();
while($item = mysql_fetch_assoc($items))
{
$attachments = $portfolio_model->GetAttachments($item['id']);
$firstPicture = "";
$num_attachments = mysql_num_rows($attachments);
if($num_attachments == 0)
    $firstPicture =  BASE_URL."static/uploads/default.jpg";
else {
    $firstPicture = mysql_fetch_assoc($attachments);
	$firstPicture = $firstPicture['attachment_path'];
}
?>
    <li>
      <div class="listLink">
        <div class="portfolioSlide"><img src="<?=$firstPicture?>" class="img-responsive mainImage" alt="" onclick="location.href = 'project/view/<?=$item['link_name'];?>';"></div>
        <?php
        if($num_attachments > 0){
        ?>
        <div class="pf-slider">
			<span class="nav-box clearfix">
			<?php
			if($num_attachments > 1){
			?>
				<span href="#" class="slideLink prevLink">prev</span>
				<span href="#" class="slideLink nextLink">next</span>
			<?php
			}
			?>
			</span>
            <?php
            mysql_data_seek($attachments, 0);
            while($attachment = mysql_fetch_assoc($attachments))
            {?>
            <img src="<?=$attachment['attachment_path'];?>" class="img-responsive" alt="" onclick="location.href = 'project/view/<?=$item['link_name'];?>';">
            <?php }
        ?>
        </div>
        <?php } ?>
        <div class="portfolioContent">
          <h3 class="font-openBold"><a href="project/view/<?=$item['link_name'];?>"><?=$item['name'];?></a> <span><?=$portfolio_model->GetCategoryName($item['category_id'])?></span></h3>
        </div>
      </div>
    </li>
<?php }
?>
</ul>
<a id=loadMoreBtn href="#" class="vc">View entire collection</a>
<div class="hiddenElm">
  <ul></ul>
</div>

<?php include('footer.php'); ?>