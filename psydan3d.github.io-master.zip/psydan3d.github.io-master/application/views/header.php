<?php
//Code by Sylvain William Martens
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Psydan3D - <?php echo $title; ?></title>
        <meta name=description content="University qualified 3D game design artist with experience in iOS & PC game asset creation.">
        <meta name=author content="Psydan3D">		
        <meta name=viewport content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>static/css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>static/css/style.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,600,700,800,300' rel='stylesheet' type='text/css'>        
        <!--socialo fonts start-->
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>static/css/socialo-fonts.css">
        <!--socialo fonts end-->
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>static/css/component.css">
        <script src="<?php echo BASE_URL; ?>static/js/modernizr.custom.js"></script>
    </head>
    <body>
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
	  ga('create', 'UA-60346063-1', 'auto');
	  ga('send', 'pageview');
	</script>
    <header class="navbar navbar-default topNav" id="top" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse"><span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                <a href="<?php echo BASE_URL; ?>" class="navbar-brand"><img src="<?php echo BASE_URL; ?>static/images/logo.png" alt="logo"><span>Psydan3D</span></a> </div>    
                <!--Menu start-->
                <nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="<?php echo BASE_URL; ?>">work</a></li>
                        <li><a href="<?php echo BASE_URL; ?>about" href="#">about</a></li>
                        <li><a href="<?php echo BASE_URL; ?>contact">contact</a></li>
                    </ul>
                </nav>
                <!--Menu end--> 
            </div>
        </div>
    </header>
    <section class="container menuBottomCon"> 
        <!--Header text start-->
        <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 topContent">
            <h3 class="font-openBold"><?php $slogan = mysql_fetch_assoc($strings_model->GetString("slogan")); echo $slogan['string_value'];?></h3>
            <h4 class="font-openRegular"><?php $subslogan = mysql_fetch_assoc($strings_model->GetString("subslogan")); echo $subslogan['string_value'];?></h4>
        </div>
        <!--Header text end--> 
        <!--Social icon start-->
        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 socialList" style="/*FIX SOCIALLINK DISPLAY:NONE FROM UNKNOWN*/ display:inline !important;">
            <ul class="list-unstyled">
            <?php
            $fb = mysql_fetch_assoc($strings_model->GetString("facebook"));
			$fb = $fb['string_value'];
            if($fb != null && $fb != ""){
            ?>
            <li><a href="<?=$fb?>" class="facebookcircle icon"></a></li><?php }
            $twitter = mysql_fetch_assoc($strings_model->GetString("twitter"));
			$twitter = $twitter['string_value'];
            if($twitter != null && $twitter != ""){
            ?>
            <li><a href="<?=$twitter?>" class="twitterbirdcircle icon"></a></li><?php }
            $linkedin = mysql_fetch_assoc($strings_model->GetString("linkedin"));
			$linkedin = $linkedin['string_value'];
            if($linkedin != null && $linkedin != ""){
            ?>
            <li><a href="<?=$linkedin;?>" class="linkedincircle icon"></a></li><?php }
            $google = mysql_fetch_assoc($strings_model->GetString("google"));
			$google = $google['string_value'];
            if($google != null && $google != ""){
            ?>
            <li><a href="<?=$google;?>" class="googlecircle icon"></a></li><?php }
            $devianart = mysql_fetch_assoc($strings_model->GetString("devianart"));
			$devianart = $devianart['string_value'];
            if($devianart != null && $devianart != ""){
            ?>
            <li><a href="<?=$devianart;?>" class="deviantartcircle icon"></a></li><?php }
            $dribble = mysql_fetch_assoc($strings_model->GetString("dribble"));
			$dribble = $dribble['string_value'];
            if($dribble != null && $dribble != ""){
            ?>
			<li><a href="<?=$dribble;?>" class="icon" style="top: 10px;position: relative;"><div class="twitchcircle"></div></a></li><?php } ?>
            </ul>
        </div>
        <!--Social icon start--> 
        </div>
    </section>
    <div class="separator container"><span class="sepIcon intop"></span></div>
    <div class="container bodyContent grid-wrap">