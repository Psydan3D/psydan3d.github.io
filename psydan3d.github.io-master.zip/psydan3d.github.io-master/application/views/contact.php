<?php
//Code by Sylvain William Martens
include('header.php'); ?>
<div class="row" style="margin-top:50px;">
<div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 blogleft contact">
    <form method="post" name="cform" id="cform">
    <h3 class="contactTitle"><?php $contact_h1 = mysql_fetch_assoc($strings_model->GetString("contact_h1")); echo $contact_h1['string_value'];?></h3>
    <p><?php $contact_subtext = mysql_fetch_assoc($strings_model->GetString("contact_subtext")); echo $contact_subtext['string_value'];?></p>
    <!--contact form start-->
    <div class="row conrow">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <input type="text" class="form-control" placeholder="First name" id="faname" name="faname">
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <input type="text" class="form-control" placeholder="Last name" id="laname" name="laname">
        </div>
    </div>
    <div class="row conrow">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <input type="text" class="form-control" placeholder="Company" id="company" name="company">
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <input type="text" class="form-control" placeholder="Phone no" id="phone" name="phone">
        </div>
    </div>
    <div class="row conrow">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <input type="text" class="form-control" placeholder="Email address" name="email" id="email"/>
        </div>
    </div>
    <div class="row conrow">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <textarea class="form-control" rows="3" placeholder="Comments" name="comments" id="comments"></textarea>
        </div>
    </div>
    <div class="row conrow">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <input type="submit" value="submit" id="submit" name="send">
        </div>
    </div>
    <div id="simple-msg"></div>
    </form>
    <div id="message"></div>
</div>
<!--contact form end--> 
<!--contact details start-->
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-md-offset-1 col-lg-offset-1 col-sm-offset-1 col-xs-offset-0 contactSide">
    <h3 class="contactTitle"><?php $contact_h2 = mysql_fetch_assoc($strings_model->GetString("contact_h2")); echo $contact_h2['string_value'];?></h3>
    <ul class="list-unstyled contactDetails">
    <li><i class="fa fa-map-marker fa-lg"></i><?php $address = mysql_fetch_assoc($strings_model->GetString("contact_address")); $address = $address['string_value']; echo $address;?></li>
    <?php $email = mysql_fetch_assoc($strings_model->GetString("contact_email")); $email = $email['string_value'];?>
    <li><i class="fa fa-envelope-o "></i><a href="mailto:<?=$email;?>"><?=$email;?></a></li>
    <li><i class="fa fa-link "></i><a href="<?php echo BASE_URL; ?>"><?php echo BASE_URL; ?></a></li>
    <li><i class="fa fa-mobile fa-lg"></i><?php $contact_phone = mysql_fetch_assoc($strings_model->GetString("contact_phone")); echo $contact_phone['string_value'];?></li>
    </ul>
</div>
<!--contact details end--> 
</div>
<!--Contact area start-->
<!--google map start-->
<div class="mapArea container">
<iframe src="https://www.google.com/maps?q=<?=$address;?>&amp;output=embed" width="100%" height="240" frameborder="0" style="border:0"></iframe>
</div>
<!--google map end--> 
<?php include('footer.php'); ?>