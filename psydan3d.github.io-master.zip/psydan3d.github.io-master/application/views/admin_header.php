<?php
//Code by Sylvain William Martens?><!DOCTYPE html><html lang="en-us" class=" -webkit-">
<head>
<meta charset="utf-8">
<title><?php echo $title; ?></title>
<meta name=description content="">
<meta name=author content="">		
<meta name=viewport content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel=stylesheet type="text/css" media="screen" href="<?php echo BASE_URL; ?>static/admin/css/bootstrap.min.css">
<link rel=stylesheet type="text/css" media="screen" href="<?php echo BASE_URL; ?>static/admin/css/font-awesome.min.css">
<link rel=stylesheet type="text/css" media="screen" href="<?php echo BASE_URL; ?>static/admin/css/main.css">
<link rel=stylesheet href="https://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,300,400,700">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
</head>
<body class="menu-on-top">
<header id=header>
	<div id="logo-group"><span id=logo><h1 style="margin-top:-01px;width:190px;height:20px;">Admin Panel</h1></span></div>			
	<!-- pulled right: nav area -->
	<div class="pull-right">
		<div id="hide-menu" class="btn-header pull-right"><span> <a href="javascript:void(0);" data-action="toggleMenu" title="Collapse Menu"><i class="fa fa-reorder"></i></a> </span></div>
		<!-- #MOBILE -->
        <a href="<?php echo BASE_URL; ?>logout">Logout</a>
	</div>
	<!-- end pulled right: nav area -->
</header>
<form id="languageForm" action="/language" method="post"><input type="hidden" name="next" value="<?php echo $next; ?>"/><input type="hidden" name="language" id="languageInput" value=""/></form>
<aside id="left-panel">
<nav>
<ul>
	<li class=""><a href="<?php echo BASE_URL; ?>admin" title="Dashboard"><i class="fa fa-lg fa-fw fa-home"></i> <span class="menu-item-parent">Dashboard</span></a></li>
	<li><a href="<?php echo BASE_URL; ?>admin/analysis"><i class="fa fa-lg fa-fw fa-bar-chart-o"></i> <span class="menu-item-parent">Analysis</span></a></li>
	<li><a href="<?php echo BASE_URL; ?>admin/administration"><i class="fa fa-lg fa-fw fa-table"></i> <span class="menu-item-parent">Administration</span></a></li>
	<li>
		<a href="<?php echo BASE_URL; ?>admin/portfolio"><i class="fa fa-lg fa-fw fa-pencil-square-o"></i> <span class="menu-item-parent">Portfolio</span></a>
		<ul>
			<li><a href="<?php echo BASE_URL; ?>admin/portfolio">Overview</a></li>
			<li><a href="<?php echo BASE_URL; ?>admin/portfolio/addItem">Add an Item</a></li>
		</ul>
	</li>
</ul>
</nav>
<span class="minifyme" data-action="minifyMenu"> <i class="fa fa-arrow-circle-left hit"></i> </span>
</aside>
<div id="main" role="main">
<div id="ribbon"><ol class="breadcrumb"><?php echo $breadcrumb;?></ol></div>
<div id="content">