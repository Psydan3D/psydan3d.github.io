<?php
//Code by Sylvain William Martens
class Portfolio_model extends Model {
  public function GetProject($projectName)
  {
    $projectName = $this->escapeString($projectName);
    $query = "SELECT * FROM portfolio_items WHERE link_name='$projectName' LIMIT 1";
    return $this->execute($query);
  }
  public function GetItem($itemId)
  {
    $itemId = $this->escapeString($itemId);
    $query = "SELECT * FROM portfolio_items WHERE id='$itemId' LIMIT 1";
    $exec = $this->execute($query);
    if(mysql_num_rows($exec) == 1) return mysql_fetch_assoc($exec);
    return null;
  }
  public function SetItem($itemId, $project_name, $project_description, $project_date, $project_client, $project_link, $project_selected_catId)
  {
    $itemId = $this->escapeString($itemId);
    $project_name = $this->escapeString($project_name);
    $project_description = $this->escapeString($project_description);
    $project_date = $this->escapeString($project_date);
    $project_client = $this->escapeString($project_client);
    $project_link = $this->escapeString($project_link);
    $project_selected_catId = $this->escapeString($project_selected_catId);
    $query = "UPDATE portfolio_items SET name='$project_name', description='$project_description', dateAt='$project_date', client_name='$project_client', project_link='$project_link', category_id='$project_selected_catId' WHERE id='$itemId' LIMIT 1";
    return $this->execute($query);
  }
  public function GetItems()
  {
    $query = "SELECT * FROM portfolio_items ORDER BY id DESC";
    return $this->execute($query);
  }
  public function GetLatest10Items()
  {
    $query = "SELECT * FROM portfolio_items ORDER BY id DESC LIMIT 10";
    return $this->execute($query);
  }
  public function GetLatest10ItemsWithOffset($offset)
  {
    $realOffset = 10 * intval($offset);
    $query = "SELECT * FROM portfolio_items ORDER BY id DESC LIMIT 10 OFFSET ".$realOffset;
    return $this->execute($query);
  }
  public function GetCategoryName($categoryId)
  {
    $categoryId = $this->escapeString($categoryId);
    $query = "SELECT name FROM portfolio_category WHERE id='$categoryId' LIMIT 1";
    $exec = $this->execute($query);
    $row = mysql_fetch_assoc($exec);
    return $row['name'];
  }
  public function GetCategories()
  {
    $query = "SELECT * FROM portfolio_category ORDER BY id DESC";
    return $this->execute($query);
  }
  public function CategoryExist($categoryId)
  {
    $categoryId = $this->escapeString($categoryId);
    $query = "SELECT id FROM portfolio_category WHERE id='$categoryId' LIMIT 1";
    $exec = $this->execute($query);
    if(mysql_num_rows($exec) == 1) return true;
    return false;
  }
  public function AddCategory($categoryName, $categoryDescription)
  {
    $categoryName = $this->escapeString($categoryName);
    $categoryDescription = $this->escapeString($categoryDescription);
    $query = "INSERT INTO portfolio_category (name, description) VALUES ('$categoryName', '$categoryDescription')";
    return $this->execute($query);
  }
  public function SetCategory($catId, $categoryName, $categoryDescription)
  {
    $catId = $this->escapeString($catId);
    $categoryName = $this->escapeString($categoryName);
    $categoryDescription = $this->escapeString($categoryDescription);
    $query = "UPDATE portfolio_category SET name='$categoryName', description='$categoryDescription' WHERE id='$catId' LIMIT 1";
    return $this->execute($query);
  }
  public function RemoveCategory($catId)
  {
    $catId = $this->escapeString($catId);
    $query = "DELETE FROM portfolio_category WHERE id='$catId' LIMIT 1";
    return $this->execute($query);
  }
  public function RemoveItem($catId)
  {
    $catId = $this->escapeString($catId);
    $query = "DELETE FROM portfolio_items_attachments WHERE item_id='$catId'";
	$this->execute($query);
    $query = "DELETE FROM portfolio_items WHERE id='$catId' LIMIT 1";
    return $this->execute($query);
  }
  public function AddItem($project_name, $project_description, $project_date, $project_client, $project_link, $project_selected_catId)
  {
    $project_name = $this->escapeString($project_name);
    $project_description = $this->escapeString($project_description);
    $project_date = $this->escapeString($project_date);
    $project_client = $this->escapeString($project_client);
    $project_link = $this->escapeString($project_link);
    $project_selected_catId = $this->escapeString($project_selected_catId);
    $friendly_url_name = preg_replace('/[^A-z 0-9]/i','', $project_name);
    $friendly_url_name = str_replace(' ', '-', $friendly_url_name);//TODO: ASAP    
    $query = "INSERT INTO portfolio_items (name, description, dateAt, client_name, project_link, category_id, link_name) VALUES ('$project_name', '$project_description', '$project_date', '$project_client', '$project_link', '$project_selected_catId', '$friendly_url_name')";
    $this->execute($query);
    return mysql_insert_id();
  }
  public function AddItemAttachment($itemId, $target_file)
  {
    $itemId = $this->escapeString($itemId);
    $target_file = $this->escapeString($target_file);
    $query = "INSERT INTO portfolio_items_attachments (item_id, attachment_path) VALUES ('$itemId', '$target_file')";
    $this->execute($query);
  }
  public function GetAttachments($itemId)
  {
    $itemId = $this->escapeString($itemId);
    $query = "SELECT * FROM portfolio_items_attachments WHERE item_id='$itemId' ORDER BY id ASC";
    return $this->execute($query);
  }
  public function GetPreviousPostLinkName($currentId)
  {
    $currentId = intval($currentId);
    $currentId--;
    $query = "SELECT * FROM portfolio_items WHERE id='$currentId' LIMIT 1";
    $exec = $this->execute($query);
    if(mysql_num_rows($exec) > 0){
        $row = mysql_fetch_assoc($exec);
        return $row['link_name'];
    }else
        return null;
  }
  public function GetNextPostLinkName($currentId)
  {
    $currentId = intval($currentId);
    $currentId++;
    $query = "SELECT * FROM portfolio_items WHERE id='$currentId' LIMIT 1";
    $exec = $this->execute($query);
    if(mysql_num_rows($exec) > 0){
        $row = mysql_fetch_assoc($exec);
        return $row['link_name'];
    }else
        return null;
  }
}
?>