<?php
//Code by Sylvain William Martens
class Skills_model extends Model {
  public function GetSkills()
  {
    $query = "SELECT * FROM skills ORDER BY id DESC LIMIT 10";
    return $this->execute($query);
  }
  public function AddSkill($skillName, $skillPercent)
  {
    $skillName = $this->escapeString($skillName);
    $skillPercent = $this->escapeString($skillPercent);
    $query = "INSERT INTO skills (name, percent) VALUES ('$skillName', '$skillPercent')";
    return $this->execute($query);
  }
  public function SetSkill($skillId, $skillName, $skillPercent)
  {
    $skillId = $this->escapeString($skillId);
    $skillName = $this->escapeString($skillName);
    $skillPercent = $this->escapeString($skillPercent);
    $query = "UPDATE skills SET name='$skillName', percent='$skillPercent' WHERE id='$skillId'";
    return $this->execute($query);
  }
  public function RemoveSkill($skillId)
  {
    $skillId = $this->escapeString($skillId);
    $query = "DELETE FROM skills WHERE id='$skillId' LIMIT 1";
    return $this->execute($query);
  }
}
?>