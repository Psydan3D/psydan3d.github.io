<?php
//Code by Sylvain William Martens
class Account_model extends Model {
  public function setLanguage($accountId, $language)
  {
    $language = "en";
    switch($_POST['language'])
    {
      case "fr":
        $language = "fr";
      break;
      case "es":
        $language = "es";
      break;
      case "de":
        $language = "de";
      break;
      //etc...
    }
    $accountId = $this->escapeString($accountId);//This function is only called by a secure location, but since this function is public, as additional security we clean it before sending it to MySQL
    $query = "UPDATE accounts SET lang='$language' WHERE id='$accountId'";
    $this->execute($query);
    //$stmt = $this->connection->prepare("UPDATE accounts SET lang=? WHERE id=?");
    //$stmt->execute(array($language, $accountId));
  }
}
?>