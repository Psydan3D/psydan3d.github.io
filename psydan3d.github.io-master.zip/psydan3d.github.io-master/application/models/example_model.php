<?php
//Code by Sylvain William Martens
class Example_model extends Model {	
	public function getSomething($id)
	{
		$id = $this->escapeString($id);
		$result = $this->query('SELECT * FROM something WHERE id="'. $id .'"');
		return $result;
	}
}
?>