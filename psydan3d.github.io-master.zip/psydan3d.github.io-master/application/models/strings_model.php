<?php
//Code by Sylvain William Martens
class Strings_model extends Model {
  public function GetString($stringName)
  {
    $stringName = $this->escapeString($stringName);
    $query = "SELECT * FROM strings WHERE name='$stringName' LIMIT 1";
    return $this->execute($query);
  }
  public function SetString($stringName, $stringValue)
  {
    $stringName = $this->escapeString($stringName);
    $stringValue = $this->escapeString($stringValue);
    $query = "UPDATE strings SET string_value='$stringValue' WHERE name='$stringName'";
    return $this->execute($query);
  }
}
?>