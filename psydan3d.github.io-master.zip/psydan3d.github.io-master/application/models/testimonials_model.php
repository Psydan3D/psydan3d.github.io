<?php
//Code by Sylvain William Martens
class Testimonials_model extends Model {
  public function GetTestimonials()
  {
    $query = "SELECT * FROM testimonials ORDER BY id DESC";
    return $this->execute($query);
  }
  public function AddTestimonial($clientName, $clientText, $clientPathPicture)
  {
    $clientName = $this->escapeString($clientName);
    $clientText = $this->escapeString($clientText);
    $clientPathPicture = $this->escapeString($clientPathPicture);
    $query = "INSERT INTO testimonials (client_name, description, picture) VALUES ('$clientName', '$clientText', '$clientPathPicture')";
    return $this->execute($query);
  }
  public function SetTestimonial($testimonialId, $clientName, $clientText)
  {
    $testimonialId = $this->escapeString($testimonialId);
    $clientName = $this->escapeString($clientName);
    $clientText = $this->escapeString($clientText);
    $query = "UPDATE testimonials SET client_name='$clientName', description='$clientText' WHERE id='$testimonialId' LIMIT 1";
    return $this->execute($query);
  }
  public function SetTestimonialPicture($testimonialId, $picture)
  {
    $testimonialId = $this->escapeString($testimonialId);
    $picture = $this->escapeString($picture);
    $query = "UPDATE testimonials SET picture='$picture' WHERE id='$testimonialId' LIMIT 1";
    return $this->execute($query);
  }
  public function RemoveTestimonial($testimonialId)
  {
    $testimonialId = $this->escapeString($testimonialId);
    $query = "DELETE FROM testimonials WHERE id='$testimonialId' LIMIT 1";
    return $this->execute($query);
  }
}
?>