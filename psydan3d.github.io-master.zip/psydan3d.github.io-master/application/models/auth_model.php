<?php
//Code by Sylvain William Martens
class Auth_model extends Model {
    public $AccountId = "";
    private $Session_helper;
    public function requireAuth($session_helper)
    {
        $this->Session_helper = $session_helper;
        if($this->Session_helper->exist("session_id") && $this->Session_helper->exist("session_key"))
        {
            $session = $this->getAuthSession($this->Session_helper->get("session_id"), $this->Session_helper->get("session_key"));
            if(mysql_num_rows($session) == 0)
            $this->redirect("login");
            else{
            $row = mysql_fetch_assoc($session);
            $last_update = $row['updated_at'];
            //TODO: If last update is more then 5 minutes ago ... delete sessions in sql and destroy session on client then redirect to Session Time Out Page...
        
            //If everything is fine lets assign our account Id and Update our session so it does not time out soon :D.
            $this->AccountId = $row['account_id'];
            //TODO: If Last update is more then a minute ago ... update session ( Prevent additional MySQL Spam )
            $this->updateSession($this->Session_helper->get("session_id"));
            }
        }else{
            $this->redirect("login");
        }
    }
    public function doLogout($session_helper)
    {
        $this->Session_helper = $session_helper;
        if($this->Session_helper->exist("session_id") && $this->Session_helper->exist("session_key"))
        {
            $session_id = $this->escapeString($this->Session_helper->get("session_id"));
            $session_key = $this->escapeString($this->Session_helper->get("session_key"));
            $ip = $_SERVER['REMOTE_ADDR'];
            $query = "DELETE FROM sessions WHERE id='$session_id' AND secret='$session_key' AND ip='$ip'";
            $this->execute($query);
            $this->Session_helper->destroy();
        }
    }
    public function doLogin($email_address, $password)
    {
        $email_address = $this->escapeString($email_address);
        $password = SHA1($password);
        $query = "SELECT id FROM accounts WHERE email_address='$email_address' AND password='$password' AND banned='0' LIMIT 1";
        $result = $this->execute($query);
        if(mysql_num_rows($result) == 1)
        {
            $rows = mysql_fetch_assoc($result);
            $this->createAuthSession($rows['id']);
            return true;
        }
        return false;
    }
    //This function is used on page which does not call the function 'requireAuth()' such as the Login page
    public function isAuthenticated($session_helper)
    {
        $this->Session_helper = $session_helper;
        if($this->Session_helper->exist("session_id") && $this->Session_helper->exist("session_key"))
        {
            $session = $this->getAuthSession($this->Session_helper->get("session_id"), $this->Session_helper->get("session_key"));
            if(mysql_num_rows($session) == 1)
            {
            $row = mysql_fetch_assoc($session);
            $last_update = $row['updated_at'];
            //TODO: If last update is more then 5 minutes ago ... delete sessions in sql and destroy session on client then redirect to Session Time Out Page...
        
            //If everything is fine lets assign our account Id.
            $AccountId = $row['id'];
            return true;
            }
        }
        return false;
    }
    private function updateSession($sessionId)
    {
        $sessionId = $this->escapeString($sessionId);  
        $query = "UPDATE sessions SET updated_at=NOW() WHERE id='$sessionId'";
        $this->execute($query);
    }
    private function createAuthSession($accountId)
    {
        $id = $this->generateSessionId();
        $secret = $this->generateSessionKey();
        $ip = $_SERVER['REMOTE_ADDR'];
        $accountId = $this->escapeString($accountId);//Should not be needed since the function is private and is only called in this Class by 'doLogin()' which got the accountId from MySQL, but as additional security we clean it before sending it to MySQL
        $query = "INSERT INTO sessions (id, account_id, secret, ip, created_at, updated_at) VALUES ('$id', '$accountId', '$secret', '$ip', NOW(), NOW())";
        $result = $this->execute($query);
        //$session_helper = $this->loadHelper("Session_helper");
        $this->Session_helper->set('session_id', $id);
        $this->Session_helper->set('session_key', $secret);
    }
    private function getAuthSession($id, $key)
    {
	    $id = $this->escapeString($id);
    $key = $this->escapeString($key);
    $ip = $_SERVER['REMOTE_ADDR'];
	    $result = $this->execute('SELECT * FROM sessions WHERE id="'. $id .'" AND secret="'. $key .'" AND ip="'. $ip .'" LIMIT 1');
	    return $result;
    }
    private function generateSessionId()
    {
		$charid = mt_rand(1000,10000);
		$charid .= mt_rand(1000,10000);
		$charid .= mt_rand(1000,10000);
		$charid .= mt_rand(1000,10000);
		return $charid;
    }
    private function generateSessionKey()
    {
		$charid = mt_rand(1000,10000);
		$charid .= mt_rand(1000,10000);
		$charid .= mt_rand(1000,10000);
		$charid .= mt_rand(1000,10000);
		return $charid;
    }
}
?>