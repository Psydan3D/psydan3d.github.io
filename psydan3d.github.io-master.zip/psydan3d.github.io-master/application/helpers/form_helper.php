<?php
//Code by Sylvain William Martens
class Form_helper {
  public function postExist($key)
  {
      return isset($_POST["$key"]);
  }
  public function get($key)
  {
      return $_POST["$key"];
  }
  public function lenghtBetween($min, $max, $field)
  {
    if(strlen($field) < $min) return false;
    if(strlen($field) > $max) return false;
    return true;
  }
  public function validEmailAddress($email_address)
  {
    //TODO: Do magic here...
    return true;
  }
}
?>