<?php
//Code by Sylvain William Martens
class Session_helper {
	public function __construct()
	{
		if(!isset($_SESSION)) session_start();
	}
    public function exist($key)
    {
    return isset($_SESSION["$key"]);
    }
    public function set($key, $val)
	{
		$_SESSION["$key"] = $val;
	}	
	public function get($key)
	{
		return $_SESSION["$key"];
	}
	public function destroy()
	{
		session_destroy();
	}
}
?>