<?php
//Code by Sylvain William Martens
class Test extends Controller {
    private $Template = null;
	function index()
	{
		$this->Template = $this->loadView('test');
		$this->Template->set('title', "Test - Control Panel");
        $this->Template->set('next', "test");
        $this->Template->set('breadcrumb', '<li>Test</li>');
		$this->Template->render();
	}
	function epic($id)
	{
		if($this->IsNullOrEmpty($id)) $this->redirect("../test");
		$this->Template = $this->loadView('test');
		$this->Template->set('title', "$id Test - Control Panel");
        $this->Template->set('next', "test/epic/$id");
        $this->Template->set('breadcrumb', '<li><a href="/test">Test</a></li><li>'."$id Test".'</li>');
		$this->Template->render();
	}  
	function damm($id, $test)
	{
		if($this->IsNullOrEmpty($id)||$this->IsNullOrEmpty($test)) $this->redirect("../test");
		$this->Template = $this->loadView('test');
		$this->Template->set('title', "$id $test Test - Control Panel");
        $this->Template->set('next', "test/epic/$id/$test");
        $this->Template->set('breadcrumb', '<li><a href="/test">Test</a></li><li>'."$id $test Test".'</li>');
		$this->Template->render();
	}    
}
?>