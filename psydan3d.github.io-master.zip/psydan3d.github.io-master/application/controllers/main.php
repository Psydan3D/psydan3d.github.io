<?php
//Code by Sylvain William Martens
class Main extends Controller {
    private $Template = null;
    private $Session_helper = null;
    private $Auth_model = null;
    private $Portfolio_model = null;
    private $Strings_model = null;
    private $Testimonials_model = null;
    private function Initialize()
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        //$this->Auth_model->requireAuth($this->Session_helper);//Not Needed here
        $this->Portfolio_model = $this->loadModel("Portfolio_model");
        $this->Strings_model = $this->loadModel("Strings_model");
        $this->Testimonials_model = $this->loadModel("Testimonials_model");
    }
	function index()
	{
        $this->Initialize();
		$this->Template = $this->loadView('index');
		$this->Template->set('title', "Freelance 3D modeling and design services");
        $this->Template->set('next', "");
        $this->Template->set('portfolio_model', $this->Portfolio_model);
        $this->Template->set('strings_model', $this->Strings_model);
        $this->Template->set('testimonials_model', $this->Testimonials_model);
		$this->Template->render();
	}
}
?>