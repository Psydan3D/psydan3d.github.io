<?php
//Code by Sylvain William Martens
class Login extends Controller {
    private $Template = null;
    private $Session_helper = null;
    private $Auth_model = null;
    private $Form_helper = null;
    private $Testimonials_model = null;
    private function Initialize()
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        if($this->Auth_model->isAuthenticated($this->Session_helper)) $this->redirect("");
        $this->Testimonials_model = $this->loadModel("Testimonials_model");
    }
	function index()
	{
        $this->Initialize();
		$this->Template = $this->loadView('login');
		$this->Template->set('title', "Login - Control Panel");
        $this->Template->set('testimonials_model', $this->Testimonials_model);
        $email_address = "";
        $error_message = "";
        //Handle Login POST
        if(isset($_POST['login']))
        {
          $error_count = 0;
          $this->Form_helper = $this->loadHelper("Form_helper");
          $password = "";
          if(!isset($_POST['email_address'])){
            $error_count++;
            $error_message .= "An email address is required to login.<br/>";
          }else{
            if(!$this->Form_helper->validEmailAddress($_POST['email_address']))
            {
              $error_count++;
              $error_message .= "Please enter a valid email address.<br/>";
            }else{
              $email_address = $_POST['email_address'];
            }
          }
          if(!isset($_POST['password'])){
            $error_count++;
            $error_message .= "A password is required to login.<br/>";
          }else{
            if(!$this->Form_helper->lenghtBetween(6, 25, $_POST['password']))
            {
              $error_count++;
              $error_message .= "Password lenght must be between 6 and 25 characters.<br/>";
            }else{
              $password = $_POST['password'];
            }
          }
        if($error_count==0)
            {
                //Do Login
				//if($email_address == "psydan@gmail.com" && $password == "PingPong99!")
                if($this->Auth_model->doLogin($email_address, $password))
                {
                  $this->redirect("admin");
                }else{
                  $error_message .= "Cannot authenticate login using these details.<br/>";
                }
            }
        }
        $this->Template->set('email_address', $email_address);
        $this->Template->set('error_message', $error_message);
        //Render Page
		$this->Template->render();
	}
}
?>