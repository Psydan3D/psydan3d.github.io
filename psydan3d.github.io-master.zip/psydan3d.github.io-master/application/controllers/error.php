<?php
//Code by Sylvain William Martens
class Error extends Controller {
    private $Template = null;
	function index()
	{
		$this->Template = $this->loadView('404');
		$this->Template->set('title', "Index");
		$this->Template->render();
	}
}
?>