<?php
//Code by Sylvain William Martens
class Admin extends Controller {
    private $Template = null;
    private $Session_helper = null;
    private $Auth_model = null;
    private $Skills_model = null;
    private $Strings_model = null;
    private $Testimonials_model = null;
    private $Portfolio_model = null;
    private function Initialize()
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        $this->Auth_model->requireAuth($this->Session_helper);
        $this->Skills_model = $this->loadModel("Skills_model");
        $this->Strings_model = $this->loadModel("Strings_model");
        $this->Testimonials_model = $this->loadModel("Testimonials_model");
        $this->Portfolio_model = $this->loadModel("Portfolio_model");
    }
	function index()
	{
        $this->Initialize();
		$this->Template = $this->loadView('admin_main_view');
		$this->Template->set('title', "Dashboard - Control Panel");
        $this->Template->set('breadcrumb', "<li>Dashboard</li>");
        $this->Template->set('next', "");
		$this->Template->render();
	}    
	function analysis()
	{
        $this->Initialize();
		$this->Template = $this->loadView('admin_analysis');
		$this->Template->set('title', "Analysis - Control Panel");
        $this->Template->set('breadcrumb', "<li>Analysis</li>");
        $this->Template->set('next', "");
		$this->Template->render();
	}
	function administration()
	{
        $this->Initialize();
        if(isset($_POST['skillName']) && $_POST['skillName'] != "" && isset($_POST['percent']) && $_POST['percent'] != "")
        {
            $skillName = $_POST['skillName'];
            $skillPercent = $_POST['percent'];
            if($skillPercent < 0) $skillPercent = 0;
            if($skillPercent > 100) $skillPercent = 100;
            $this->Skills_model->AddSkill($skillName, $skillPercent);
        }
        if(isset($_POST['description']))
        {
            $description = $_POST['description'];
            $this->Strings_model->SetString("about_me", $description);
        }
        if(isset($_POST['slogan']))
        {
            $description = $_POST['slogan'];
            $this->Strings_model->SetString("slogan", $description);
        }
        if(isset($_POST['subslogan']))
        {
            $description = $_POST['subslogan'];
            $this->Strings_model->SetString("subslogan", $description);
        }
        if(isset($_POST['skills']))
        {
            $description = $_POST['skills'];
            $this->Strings_model->SetString("skills", $description);
        }
        if(isset($_POST['facebook']))
        {
            $description = $_POST['facebook'];
            $this->Strings_model->SetString("facebook", $description);
        }
        if(isset($_POST['twitter']))
        {
            $description = $_POST['twitter'];
            $this->Strings_model->SetString("twitter", $description);
        }
        if(isset($_POST['linkedin']))
        {
            $description = $_POST['linkedin'];
            $this->Strings_model->SetString("linkedin", $description);
        }
        if(isset($_POST['google']))
        {
            $description = $_POST['google'];
            $this->Strings_model->SetString("google", $description);
        }
        if(isset($_POST['devianart']))
        {
            $description = $_POST['devianart'];
            $this->Strings_model->SetString("devianart", $description);
        }
        if(isset($_POST['dribble']))
        {
            $description = $_POST['dribble'];
            $this->Strings_model->SetString("dribble", $description);
        }
        if(isset($_FILES['myPicture']))
        {
            //OK FOR THAT I NEED TO COPY SOME CODE ONLY CUZ I FORGOT HOW TO DO THE MOVE_FILE
            $target_dir = "static/images/";
            $target_file = $target_dir . "about.png";
            $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
            if (move_uploaded_file($_FILES["myPicture"]["tmp_name"], $target_file)) {
                //Display Success prompt
            } else {
                //Display Error prompt
            }
        }
        if(isset($_FILES['myResume']))
        {
            //OK FOR THAT I NEED TO COPY SOME CODE ONLY CUZ I FORGOT HOW TO DO THE MOVE_FILE
            $target_dir = "static/files/";
            $target_file = $target_dir . basename($_FILES["myResume"]["name"]);
            $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
            if (move_uploaded_file($_FILES["myResume"]["tmp_name"], $target_file)) {
                //Display Success prompt
                $this->Strings_model->SetString("path_resume", $target_file);
            } else {
                //Display Error prompt
            }
        }
        if(isset($_POST['contact_h1']))
        {
            $description = $_POST['contact_h1'];
            $this->Strings_model->SetString("contact_h1", $description);
        }
        if(isset($_POST['contact_h2']))
        {
            $description = $_POST['contact_h2'];
            $this->Strings_model->SetString("contact_h2", $description);
        }
        if(isset($_POST['contact_subtext']))
        {
            $description = $_POST['contact_subtext'];
            $this->Strings_model->SetString("contact_subtext", $description);
        }
        if(isset($_POST['contact_address']))
        {
            $description = $_POST['contact_address'];
            $this->Strings_model->SetString("contact_address", $description);
        }
        if(isset($_POST['contact_phone']))
        {
            $description = $_POST['contact_phone'];
            $this->Strings_model->SetString("contact_phone", $description);
        }
        if(isset($_POST['contact_email']))
        {
            $description = $_POST['contact_email'];
            $this->Strings_model->SetString("contact_email", $description);
        }
        //Add Testimonial
        if(isset($_FILES['client_picture']) && isset($_POST['client_name']) && $_POST['client_name'] != "" && isset($_POST['client_text']) && $_POST['client_text'] != "")
        {
            $clientname = $this->escapeString($_POST['client_name']);
            $client_text = $this->escapeString($_POST['client_text']);
            //OK FOR THAT I NEED TO COPY SOME CODE ONLY CUZ I FORGOT HOW TO DO THE MOVE_FILE
            $target_dir = "static/images/testimonials/";
            $target_file = $target_dir . $clientname.".png";
            $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
            if (move_uploaded_file($_FILES["client_picture"]["tmp_name"], $target_file)) {
                //Display Success prompt
                $this->Testimonials_model->AddTestimonial($clientname, $client_text, $target_file);
            } else {
                //Display Error prompt
            }
        }        
        //Render page
		$this->Template = $this->loadView('admin_administration');
		$this->Template->set('title', "Administration - Control Panel");
        $this->Template->set('breadcrumb', "<li>Administration</li>");
        $this->Template->set('next', "");
        $this->Template->set('skills_model', $this->Skills_model);
        $this->Template->set('strings_model', $this->Strings_model);
        $this->Template->set('testimonials_model', $this->Testimonials_model);
		$this->Template->render();
	}    
	function portfolio($subpage = null)
	{
        $this->Initialize();
        switch($subpage)
        {
            default:             
                if(isset($_POST['category_name']) && isset($_POST['category_description']))
                {
                    $category_name = $_POST['category_name'];
                    $category_description = $_POST['category_description'];
                    $this->Portfolio_model->AddCategory($category_name, $category_description);
                }
		        $this->Template = $this->loadView('admin_portfolio_overview');
		        $this->Template->set('title', "Portfolio - Control Panel");
                $this->Template->set('breadcrumb', "<li>Portfolio</li>");
                $this->Template->set('next', "");
                $this->Template->set('portfolio_model', $this->Portfolio_model);
		        $this->Template->render();
            break;
            case "addItem":
                $error = "";
                $success = false;
                $success_msg = "";
                $project_name = "";
                $project_description = "";
                $project_date = "";
                $project_client = "";
                $project_link = "";
                $project_selected_catId = "";
                if(isset($_POST['doPost']) && $_POST['doPost'] == "true")
                {
                    $error_count = 0;
                    if(!isset($_POST['name']) || (strlen($_POST['name']) < 4 || strlen($_POST['name']) > 25))
                    {
                        $error = "Please enter a valid project name between 4 and 25 characters.";
                        $error_count++;
                    }else
                        $project_name = $_POST['name'];
                    if(!isset($_POST['description']) || (strlen($_POST['description']) < 4 || strlen($_POST['description']) > 5000))
                    {
                        $error = "Please enter a valid project description between 4 and 5000 characters.";
                        $error_count++;
                    }else
                        $project_description = $_POST['description'];
                    if(!isset($_POST['dateAt']) || (strlen($_POST['dateAt']) < 4 || strlen($_POST['dateAt']) > 25))
                    {
                        $error = "Please enter a valid project date between 4 and 25 characters.";
                        $error_count++;
                    }else
                        $project_date = $_POST['dateAt'];
                    if(!isset($_POST['client']) || (strlen($_POST['client']) < 2 || strlen($_POST['client']) > 50))
                    {
                        $error = "Please enter a valid project client between 2 and 50 characters.";
                        $error_count++;
                    }else
                        $project_client = $_POST['client'];
                    if(!isset($_POST['link']) || (strlen($_POST['link']) < 2 || strlen($_POST['link']) > 100))
                    {
                        $error = "Please enter a valid project link between 2 and 100 characters.";
                        $error_count++;
                    }else
                        $project_link = $_POST['link'];
                    if(!isset($_POST['category']) || !$this->Portfolio_model->CategoryExist($_POST['category']))//Check if category exist...
                    {
                        $error = "Please select a valid project category.";
                        $error_count++;
                    }else
                        $project_selected_catId = $_POST['category'];
                    
                    if($error_count == 0)
                    {
                        //Copy Images Here... if copy fail, let the user know, but still create the portfolio .. since he can return and edit the attachment...
                        $itemId = $this->Portfolio_model->AddItem($project_name, $project_description, $project_date, $project_client, $project_link, $project_selected_catId);                        
						$my_files = array();
						foreach ($_FILES['files']['error'] as $key => $error) {
							$my_files[$key]['name'] = $_FILES['files']['name'][$key];
							$my_files[$key]['type'] = $_FILES['files']['type'][$key];
							$my_files[$key]['tmp_name'] = $_FILES['files']['tmp_name'][$key];
							$my_files[$key]['error'] = $_FILES['files']['error'][$key];
							$my_files[$key]['size'] = $_FILES['files']['size'][$key];
						}
						$count = count($my_files);
						for($i=0; $i<$count; $i+=1) { $attachment = $my_files[$i];
							$target_dir = "static/images/projects/";
							$target_file = $target_dir . $itemId."_".$i.".png";
							$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
							if (move_uploaded_file($attachment["tmp_name"], $target_file)) {
								//Display Success prompt								
								$this->Portfolio_model->AddItemAttachment($itemId, $target_file);
							} else {
								//Display Error prompt
							}
							//$this->Portfolio_model->AddItemAttachment($itemId, $attachment);
                        }
                        $success = true;
                        $success_msg = "Portfolio item '".$project_name."' created successfully.";
                        $project_name = "";
                        $project_description = "";
                        $project_date = "";
                        $project_client = "";
                        $project_link = "";
						die("success");
                    }else{
						die($error);
					}					
                }
		        $this->Template = $this->loadView('admin_portfolio_addItem');
		        $this->Template->set('title', "Add an Item - Portfolio - Control Panel");
                $this->Template->set('breadcrumb', "<li>Portfolio - Add an Item</li>");
                $this->Template->set('next', "");
                $this->Template->set('success', $success);
                $this->Template->set('success_msg', $success_msg);                
                $this->Template->set('error', $error);
                $this->Template->set('project_name', $project_name);
                $this->Template->set('project_description', $project_description);
                $this->Template->set('project_date', $project_date);
                $this->Template->set('project_client', $project_client);
                $this->Template->set('project_link', $project_link);
                $this->Template->set('project_selected_catId', $project_selected_catId);
                $this->Template->set('portfolio_model', $this->Portfolio_model);
		        $this->Template->render();
            break;
        }
	}
	function base64_to_jpeg($base64_string, $output_file) {
		$ifp = fopen($output_file, "wb");
		$data = explode(',', $base64_string);
		fwrite($ifp, base64_decode($data[1])); 
		fclose($ifp);
		return $output_file; 
	}
    function editItem($itemId = null)
    {
        if($itemId == null) $this->redirect("admin/portfolio");
        $this->Initialize();
        //TODO: Do our stuff here
        $item = $this->Portfolio_model->GetItem($itemId);
        if($item == null) $this->redirect("admin/portfolio");
        $error = "";
        $success = false;
        $success_msg = "";
        $project_name = $item['name'];
        $project_description = $item['description'];
        $project_date = $item['dateAt'];
        $project_client = $item['client_name'];
        $project_link = $item['project_link'];
        $project_selected_catId = $item['category_id'];
        if(isset($_POST['doPost']) && $_POST['doPost'] == "true")
        {
            $error_count = 0;
            if(!isset($_POST['name']) || (strlen($_POST['name']) < 4 || strlen($_POST['name']) > 25))
            {
                $error = "Please enter a valid project name between 4 and 25 characters.";
                $error_count++;
            }else
                $project_name = $_POST['name'];
            if(!isset($_POST['description']) || (strlen($_POST['description']) < 4 || strlen($_POST['description']) > 5000))
            {
                $error = "Please enter a valid project description between 4 and 5000 characters.";
                $error_count++;
            }else
                $project_description = $_POST['description'];
            if(!isset($_POST['dateAt']) || (strlen($_POST['dateAt']) < 4 || strlen($_POST['dateAt']) > 25))
            {
                $error = "Please enter a valid project date between 4 and 25 characters.";
                $error_count++;
            }else
                $project_date = $_POST['dateAt'];
            if(!isset($_POST['client']) || (strlen($_POST['client']) < 2 || strlen($_POST['client']) > 50))
            {
                $error = "Please enter a valid project client between 2 and 50 characters.";
                $error_count++;
            }else
                $project_client = $_POST['client'];
            if(!isset($_POST['link']) || (strlen($_POST['link']) < 2 || strlen($_POST['link']) > 100))
            {
                $error = "Please enter a valid project link between 2 and 100 characters.";
                $error_count++;
            }else
                $project_link = $_POST['link'];
            if(!isset($_POST['category']) || !$this->Portfolio_model->CategoryExist($_POST['category']))//Check if category exist...
            {
                $error = "Please select a valid project category.";
                $error_count++;
            }else
                $project_selected_catId = $_POST['category'];                    
            if($error_count == 0)
            {
                //No error we can do our thing and reset the variables...                        
                //Copy Images Here... if copy fail, let the user know, but still create the portfolio .. since he can return and edit the attachment...
                $this->Portfolio_model->SetItem($itemId, $project_name, $project_description, $project_date, $project_client, $project_link, $project_selected_catId);
                $success = true;
                $success_msg = "Portfolio item '".$project_name."' edited successfully.";
            }
        }
		$this->Template = $this->loadView('admin_portfolio_editItem');
		$this->Template->set('title', "Edit an Item - Portfolio - Control Panel");
        $this->Template->set('breadcrumb', "<li>Portfolio - Edit an Item</li>");
        $this->Template->set('next', "");
        $this->Template->set('success', $success);
        $this->Template->set('success_msg', $success_msg);                
        $this->Template->set('error', $error);
        $this->Template->set('project_name', $project_name);
        $this->Template->set('project_description', $project_description);
        $this->Template->set('project_date', $project_date);
        $this->Template->set('project_client', $project_client);
        $this->Template->set('project_link', $project_link);
        $this->Template->set('project_selected_catId', $project_selected_catId);
        $this->Template->set('portfolio_model', $this->Portfolio_model);
		$this->Template->render();
    }
}
?>