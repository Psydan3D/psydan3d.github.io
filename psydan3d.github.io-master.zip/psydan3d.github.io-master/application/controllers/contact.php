<?php
//Code by Sylvain William Martens
class Contact extends Controller {
    private $Template = null;
    private $Strings_model = null;
    private $Testimonials_model = null;
	function index()
	{
        $this->Strings_model = $this->loadModel("Strings_model");
        if(isset($_POST['faname']) && isset($_POST['laname']) && isset($_POST['company']) && isset($_POST['phone']) && isset($_POST['comments']) && isset($_POST['email']))
        {
            $faname = $this->escapeString($_POST['faname']);
            $laname = $this->escapeString($_POST['laname']);
            $company = $this->escapeString($_POST['company']);
            $phone = $this->escapeString($_POST['phone']);
            $email = $this->escapeString($_POST['email']);
            $comments = nl2br($_POST['comments']);
            $sendto = mysql_fetch_assoc($this->Strings_model->GetString("contact_email"));
			$sendto = $sendto['string_value'];
            $subject = 'Psydan Site: '.$faname." ".$laname. " ".date("d-M-Y");
            $message = 'Email Address: '.$email.'<br>First name: '.$faname.'<br>Last name: '.$laname.'<br>Company: '.$company.'<br>Phone: '.$phone.'<br>Message:<br>'.$comments;            
			date_default_timezone_set('Etc/UTC');
			require 'phpmailer/PHPMailerAutoload.php';
			//Create a new PHPMailer instance
			$mail = new PHPMailer;
			//Tell PHPMailer to use SMTP
			$mail->isSMTP();
			//Enable SMTP debugging
			// 0 = off (for production use)
			// 1 = client messages
			// 2 = client and server messages
			$mail->SMTPDebug = 0;
			//Ask for HTML-friendly debug output
			$mail->Debugoutput = 'html';
			//Set the hostname of the mail server
			$mail->Host = 'smtp.gmail.com';
			//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
			$mail->Port = 587;
			//Set the encryption system to use - ssl (deprecated) or tls
			$mail->SMTPSecure = 'tls';
			//Whether to use SMTP authentication
			$mail->SMTPAuth = true;
			//Username to use for SMTP authentication - use full email address for gmail
			$mail->Username = "psydanproxy@gmail.com";
			//Password to use for SMTP authentication
			$mail->Password = "gismandsor";
			//Set who the message is to be sent from
			$mail->setFrom($email, $faname." ".$laname);
			//Set an alternative reply-to address
			$mail->addReplyTo($email, $faname." ".$laname);
			//Set who the message is to be sent to
			$mail->addAddress($sendto, 'Psydan3D');
			$mail->Subject = $subject;
			$mail->msgHTML($message);
			$mail->send();
        }
        $this->Skills_model = $this->loadModel("Skills_model");
        $this->Testimonials_model = $this->loadModel("Testimonials_model");
		$this->Template = $this->loadView('contact');
		$this->Template->set('title', "Contact");
        $this->Template->set('next', "");
        $this->Template->set('strings_model', $this->Strings_model);
        $this->Template->set('testimonials_model', $this->Testimonials_model);
		$this->Template->render();
	}
}
?>