<?php
//Code by Sylvain William Martens
class Logout extends Controller {
    private $Session_helper = null;
	function index()
	{
        $this->Session_helper = $this->loadHelper("Session_helper");
        $auth_model = $this->loadModel("Auth_model");
        $auth_model->doLogout($this->Session_helper);
        $this->redirect("login");
	}
}
?>