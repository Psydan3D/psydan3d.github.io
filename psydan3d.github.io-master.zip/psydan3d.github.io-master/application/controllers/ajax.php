<?php
//Code by Sylvain William Martens
class Ajax extends Controller {
    private $Portfolio_model = null;
    private $Session_helper = null;
    private $Auth_model = null;
    private $Skills_model = null;
    private $Testimonials_model = null;
    private function Initialize()
    {
        $this->Portfolio_model = $this->loadModel("Portfolio_model");
    }
	function index()
	{
		echo "You should not be here!";
	}
    function removeItem($catId)
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        $this->Auth_model->requireAuth($this->Session_helper);//This will prevent any non-admin from removing a skill
        $this->Portfolio_model = $this->loadModel("Portfolio_model");
        $this->Portfolio_model->RemoveItem($catId);
        echo "success";//TODO: Verify if mysql return success...
    }
    function removeSkill($skillId)
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        $this->Auth_model->requireAuth($this->Session_helper);//This will prevent any non-admin from removing a skill
        $this->Skills_model = $this->loadModel("Skills_model");
        $this->Skills_model->RemoveSkill($skillId);
        echo "success";//TODO: Verify if mysql return success...
    }
    function setSkill($skillId)
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        $this->Auth_model->requireAuth($this->Session_helper);//This will prevent any non-admin from removing a skill
        $this->Skills_model = $this->loadModel("Skills_model");
        if(isset($_POST['skillName']) && $_POST['skillName'] != "" && isset($_POST['percent']) && $_POST['percent'] != "")
        {
            $skillName = $_POST['skillName'];
            $skillPercent = $_POST['percent'];
            if($skillPercent < 0) $skillPercent = 0;
            if($skillPercent > 100) $skillPercent = 100;
            $this->Skills_model->SetSkill($skillId, $skillName, $skillPercent);
            echo "success";//TODO: Verify if mysql return success...
        }else
            echo "error";
    }
    function setCategory($catId)
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        $this->Auth_model->requireAuth($this->Session_helper);//This will prevent any non-admin from removing a skill
        if(isset($_POST['category_name']) && $_POST['category_name'] != "" && isset($_POST['category_description']) && $_POST['category_description'] != "")
        {
            $category_name = $_POST['category_name'];
            $category_description = $_POST['category_description'];
            $this->Initialize();
            $this->Portfolio_model->SetCategory($catId, $category_name, $category_description);
        }
    }
    function removeCategory($catId)
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        $this->Auth_model->requireAuth($this->Session_helper);//This will prevent any non-admin from removing a skill
        $this->Portfolio_model = $this->loadModel("Portfolio_model");
        $this->Portfolio_model->RemoveCategory($catId);
        echo "success";//TODO: Verify if mysql return success...
    }
    function setTestimonial($skillId)
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        $this->Auth_model->requireAuth($this->Session_helper);//This will prevent any non-admin from removing a skill
        $this->Testimonials_model = $this->loadModel("Testimonials_model");
        if(isset($_POST['client_name']) && $_POST['client_name'] != "" && isset($_POST['client_text']) && $_POST['client_text'] != "")
        {
            $clientname = $this->escapeString($_POST['client_name']);
            $client_text = $this->escapeString($_POST['client_text']);
            $this->Testimonials_model->SetTestimonial($skillId, $clientname, $client_text);
            if(isset($_FILES['client_picture']))
            {            
                //OK FOR THAT I NEED TO COPY SOME CODE ONLY CUZ I FORGOT HOW TO DO THE MOVE_FILE
                $target_dir = "static/images/testimonials/";
                $target_file = $target_dir . $clientname.".png";
                $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
                if (move_uploaded_file($_FILES["client_picture"]["tmp_name"], $target_file)) {
                    //Display Success prompt
                    $this->Testimonials_model->SetTestimonialPicture($skillId, $target_file);
                } else {
                    //Display Error prompt
                }            
            }
        }
        echo "success";
    }
    function removeTestimonial($skillId)
    {
        $this->Auth_model = $this->loadModel("Auth_model");
        $this->Session_helper = $this->loadHelper("Session_helper");
        $this->Auth_model->requireAuth($this->Session_helper);//This will prevent any non-admin from removing a skill
        $this->Testimonials_model = $this->loadModel("Testimonials_model");
        $this->Testimonials_model->RemoveTestimonial($skillId);
        echo "success";//TODO: Verify if mysql return success...
    }
	function loadMorePortfolioItems($offset)
	{
        $this->Initialize();
		$items = $this->Portfolio_model->GetLatest10ItemsWithOffset($offset);
        if(mysql_num_rows($items) > 0){
        while($item = mysql_fetch_assoc($items))
        {
            $attachments = $this->Portfolio_model->GetAttachments($item['id']);
            $firstPicture = "";
            $num_attachments = mysql_num_rows($attachments);
            if($num_attachments == 0)
                $firstPicture =  BASE_URL."static/uploads/default.jpg";
            else {
                $firstPicture = BASE_URL."static/uploads/".mysql_fetch_assoc($attachments);
				$firstPicture = $firstPicture['attachment_path'];
			}
            ?>
            <li>
              <div class="listLink">
                <div class="portfolioSlide"><img src="<?=$firstPicture?>" class="img-responsive mainImage" alt="" onclick="location.href = 'project/view/<?=$item['link_name'];?>';"></div>
                <?php
				if($num_attachments > 0){
				?>
				<div class="pf-slider">
					<span class="nav-box clearfix">
					<?php
					if($num_attachments > 1){
					?>
						<span href="#" class="slideLink prevLink">prev</span>
						<span href="#" class="slideLink nextLink">next</span>
					<?php
					}
					?>
					</span>
					<?php
                    mysql_data_seek($attachments, 0);
                    while($attachment = mysql_fetch_assoc($attachments))
                    {?>
                    <img src="<?php echo BASE_URL; ?><?=$attachment['attachment_path'];?>" class="img-responsive" alt="" onclick="location.href = 'project/view/<?=$item['link_name'];?>';">
                    <?php }
                ?>
                </div>
                <?php } ?>
                <div class="portfolioContent">
                  <h3 class="font-openBold"><a href="project/view/<?=$item['link_name'];?>"><?=$item['name'];?></a> <span><?=$this->Portfolio_model->GetCategoryName($item['category_id'])?></span></h3>
                </div>
              </div>
            </li>
        <?php }
        }else{
            echo "END";
        }
	}
}
?>