<?php
//Code by Sylvain William Martens
class About extends Controller {
    private $Template = null;
    private $Skills_model = null;
    private $Strings_model = null;
    private $Testimonials_model = null;
	function index()
	{
        $this->Skills_model = $this->loadModel("Skills_model");
        $this->Strings_model = $this->loadModel("Strings_model");
        $this->Testimonials_model = $this->loadModel("Testimonials_model");
		$this->Template = $this->loadView('about');
		$this->Template->set('title', "About");
        $this->Template->set('next', "");
        $this->Template->set('skills_model', $this->Skills_model);
        $this->Template->set('strings_model', $this->Strings_model);
        $this->Template->set('testimonials_model', $this->Testimonials_model);
		$this->Template->render();
	}
}
?>