<?php
//Code by Sylvain William Martens
class Project extends Controller {
    private $Template = null;
    private $Skills_model = null;
    private $Strings_model = null;
    private $Portfolio_model = null;
    private $Testimonials_model = null;
    function index()
    {
        $this->redirect("");
    }
	public function view($projectName = null)
	{
        if($projectName == null); //Redirect to home page...
        $this->Portfolio_model = $this->loadModel("Portfolio_model");
        $exec = $this->Portfolio_model->GetProject($projectName);
        if(mysql_num_rows($exec) == 0) $this->redirect("");//Redirect to home page...        
        $project = mysql_fetch_assoc($exec);
        $this->Skills_model = $this->loadModel("Skills_model");
        $this->Strings_model = $this->loadModel("Strings_model");
        $this->Testimonials_model = $this->loadModel("Testimonials_model");
		$this->Template = $this->loadView('project');
		$this->Template->set('title', $project['name']);
        $this->Template->set('next', "");
        $this->Template->set('skills_model', $this->Skills_model);
        $this->Template->set('strings_model', $this->Strings_model);
        $this->Template->set('portfolio_model', $this->Portfolio_model);
        $this->Template->set('testimonials_model', $this->Testimonials_model);
        $this->Template->set('project', $project);
		$this->Template->render();
	}
}
?>